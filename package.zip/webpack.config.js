const path = require("path");
const HtmlWebPackPlugin = require("html-webpack-plugin");
const isDevelopment = process.env.NODE_ENV === "development";
module.exports = {
  entry: path.resolve(__dirname, "src/index"),
  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "[name].min.js",
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        include: path.resolve(__dirname, "src"),
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env'],
            plugins: [
              'transform-custom-element-classes',
              '@babel/plugin-proposal-class-properties'
            ]
          }
        },
      },
      {
        test: /\.(sa|sc|c)ss$/,
        use: [
         "style-loader",
          "css-loader",
          "sass-loader"
        ],
      },
    ],
  },

  plugins: [
    new HtmlWebPackPlugin({ template: "src/index.html" }),
  ],
  devServer: {
    historyApiFallback: true,
  },
  resolve: {
    alias: {
      'components': path.resolve(__dirname, 'src/components/'),
      'scss': path.resolve(__dirname, 'src/scss/')
    }
  }
};
