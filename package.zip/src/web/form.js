import React from "react";
import { render } from "react-dom";

const hero_banner = {
  background: "#b0eae8",
  padding: "60px 80px 20px",
  textAlign: "center",
  margin:"0"
};
const hero_banner_content = {
  color: "#022b49",
  fontSize: "18px",
  fontFamily: "Arial",
  fontWeight: "bold",
  margin: "20px auto",
};
const hero_img = {
  maxWidth: "100%",
  height: "300px",
};

const HeroBanner = ({ data }) => {
  return (
    <figure style={hero_banner}>
      <img style={hero_img} src={data.imgURL} alt="" />
      <figcaption style={hero_banner_content}>{data.desc_1}</figcaption>
      <figcaption style={hero_banner_content}>{data.desc_2}</figcaption>
    </figure>
  );
};

class XSearch extends HTMLElement {
  connectedCallback() {
    const mountPoint = document.createElement("span");
    this.attachShadow({ mode: "open" }).appendChild(mountPoint);
    const name = JSON.parse(this.getAttribute("field"));
    if (name) {
      render(<HeroBanner data={name} />, mountPoint);
    }
  }
}

window.customElements.define("custom-form", XSearch);
