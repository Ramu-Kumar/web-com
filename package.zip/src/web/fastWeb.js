import React from 'react';
import ReactWebComponent from 'react-web-component';
import '../App.css'

class App extends React.Component {
  render() {
    return <div className="hello uyl">Hello World!</div>;
  }
}

ReactWebComponent.create(<App/>, 'my-component' , true);