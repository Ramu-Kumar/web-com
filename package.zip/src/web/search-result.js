const template = document.createElement("template");
template.innerHTML = `
  <style>
    div {
      margin-top: 20px;
      color: green;
      font-size:20px;
    }
    span {
       color : black;
    }

  </style>
  <div>
    <p>
      <span id="menu_desc"> </span> 
      <br/>
      The Google search result of your name is <a target="_blank" rel="noopener">here</a>
    </p>
  </div>
`;

class SearchResult extends HTMLElement {
  constructor() {
    super();

    this.attachShadow({ mode: "open" });

    this.shadowRoot.appendChild(template.content.cloneNode(true));

    this.shadowRoot.querySelector("a").href = "";
    this.shadowRoot.querySelector("span").innerHTML = ""
  }

  static get observedAttributes() {
    return ["name-attribute"];
  }

  attributeChangedCallback(name, oldValue, newValue) {
    if (name === "name-attribute") {
      this.shadowRoot.querySelector(
        "a"
      ).href = `https://www.google.com/search?q=${newValue}`;

      this.shadowRoot.querySelector("span").innerHTML = `Hello ${newValue}`
    }
  }
}

window.customElements.define("search-result", SearchResult);
