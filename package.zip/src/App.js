import React, { useState, Suspense } from "react";

import "./App.css";
import(/* webpackChunkName: "searchResult" */ "./web/search-result");
import(/* webpackChunkName: "customForm" */ "./web/form");
import(/* webpackChunkName: "fastWeb" */ "./web/fastWeb");

const sampleData = {
  imgURL:
    "https://www.radiangives.com/-/media/Radian/Project/Radian-Microsites/Post-Cards/RAD-Holiday-DigitalPostcard1.jpg",
  desc_1: `Everyone has different traditions that make the holidays memorable. From
  the foods you cook and the music you play, to annual gatherings with
  family and rituals shared with friends, there are a million ways to make
  the season meaningful.`,
  desc_2: ` This year, we invite you to join us as we honor one of our longstanding
  traditions: giving back. Together, we can help people in need and make
  their holiday celebrations even brighter.`,
};

function App() {
  const [name, setName] = useState("Ramu");

  return (
    <div className="App">
      <Suspense fallback={() => <div>Loading....</div>}>
        <custom-form field={JSON.stringify(sampleData)}></custom-form>
        <custom-form></custom-form>
        <my-component></my-component>
      </Suspense>
      <Suspense fallback={() => <div>Loading....</div>}>
        <my-component></my-component>
      </Suspense>
    </div>
  );
}

export default App;
