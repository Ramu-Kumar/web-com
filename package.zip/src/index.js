import React from "react";
import { render } from "react-dom";
import App from "./App.js";
import './App.css'


const rootElement = document.querySelector("#react-app");

render(<App />, rootElement);
